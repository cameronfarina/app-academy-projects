// var baseConfig = {
//     entry: './src/index.js'
// };