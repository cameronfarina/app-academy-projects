game.run
    board.render
    ask the user for a grid positon like 0,0
    ask the user for a value 1-9
    set the value on the board at the position the user specified with the value they specified
    check to see if the board is


@board = Array.new(9) { Array.new(9, nil)}

board.populate

board.render

